const roster = document.getElementById('roster');
const regions = [...new Set(teams.map(t=>t.r))];
regions.forEach(r=>{
  const block = document.createElement('div');
  block.className='region-block';
  block.innerHTML = `<div class="region-label">${r}</div>`;
  const row = document.createElement('div'); row.style.display='flex'; row.style.flexWrap='wrap'; row.style.gap='8px';
  teams.filter(t=>t.r===r).forEach(t=>{
    const c = document.createElement('div');
    c.className='card'; c.draggable=true; c.dataset.name=t.n; c.dataset.region=t.r; c.dataset.pop=t.p;
    c.innerHTML = `<span class="dot"></span>${t.n}`;
    c.addEventListener('dragstart', e=>{ c.classList.add('dragging'); e.dataTransfer.setData('text/plain', JSON.stringify({n:t.n,r:t.r,p:t.p})); });
    c.addEventListener('dragend', ()=> c.classList.remove('dragging'));
    c.addEventListener('click', ()=> pickIntoOpenSlot({n:t.n,r:t.r,p:t.p})); // tap-to-pick fallback for mobile
    row.appendChild(c);
  });
  block.appendChild(row);
  roster.appendChild(block);
});

const evSel = document.getElementById('event');
events.forEach((e,i)=>{ const o=document.createElement('option'); o.value=i; o.textContent=e.name; evSel.appendChild(o); });

let picked = {A:null, B:null};
const slots = {A:document.getElementById('slotA'), B:document.getElementById('slotB')};

function renderSlot(key){
  const el = slots[key]; const t = picked[key];
  el.innerHTML = t ? `<div class="picked">${t.n}<span class="region">${t.r}</span></div>` : `<div class="placeholder">Drag Team ${key} here</div>`;
}
function pickIntoOpenSlot(t){
  if(!picked.A){ picked.A=t; } else if(!picked.B){ picked.B=t; } else { picked.A=t; picked.B=null; }
  renderSlot('A'); renderSlot('B'); compute();
}

Object.entries(slots).forEach(([key, el])=>{
  el.addEventListener('dragover', e=>{ e.preventDefault(); el.classList.add('over'); });
  el.addEventListener('dragleave', ()=> el.classList.remove('over'));
  el.addEventListener('drop', e=>{
    e.preventDefault(); el.classList.remove('over');
    try{ picked[key] = JSON.parse(e.dataTransfer.getData('text/plain')); renderSlot(key); compute(); }catch(err){}
  });
});

document.getElementById('marquee').addEventListener('change', compute);
evSel.addEventListener('change', compute);

function fmt(n){ return Math.round(n).toLocaleString('en-US'); }

function compute(){
  const result = document.getElementById('result');
  if(!picked.A || !picked.B){ result.innerHTML = '<div class="empty">Pick two teams and an event to see the prediction.</div>'; return; }
  const ev = events[evSel.value];
  const marquee = document.getElementById('marquee').checked;
  const teamFactor = (picked.A.p + picked.B.p)/2;
  const sameRegion = picked.A.r === picked.B.r;
  const matchupBonus = ev.intl ? (sameRegion?1.0:1.1) : (sameRegion?1.05:1.0);
  let avg = ev.avg * teamFactor * matchupBonus * (marquee?1.5:1.0);
  let peak = avg * ev.peakR * (marquee?1.15:1.0);
  result.innerHTML = `
    <div style="font-size:.85rem;color:var(--sub)">${picked.A.n} <span style="color:var(--red)">vs</span> ${picked.B.n} — ${ev.name}${marquee? ' · Marquee':''}</div>
    <div class="row">
      <div class="metric"><div class="num">${fmt(avg)}</div><div class="lbl">Avg. Concurrent Viewers</div></div>
      <div class="metric"><div class="num">${fmt(peak)}</div><div class="lbl">Peak Concurrent Viewers</div></div>
    </div>
  `;
}
