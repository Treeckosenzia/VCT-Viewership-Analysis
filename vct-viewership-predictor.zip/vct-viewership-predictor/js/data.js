// Team roster: p = brand-strength weight (1.0 = average tier-1 team).
// Weights are a judgment call calibrated from publicly reported Esports Charts
// aggregates (team/event/match average & peak concurrent viewers), not a live
// data pull. Adjust freely as team form and popularity shift.
const teams = [
  {n:"Sentinels",r:"Americas",p:1.35},{n:"NRG",r:"Americas",p:1.5},{n:"LOUD",r:"Americas",p:1.5},
  {n:"G2 Esports",r:"Americas",p:1.4},{n:"100 Thieves",r:"Americas",p:1.1},{n:"Cloud9",r:"Americas",p:1.0},
  {n:"Evil Geniuses",r:"Americas",p:1.0},{n:"FURIA",r:"Americas",p:1.0},{n:"MIBR",r:"Americas",p:1.0},
  {n:"Leviatán",r:"Americas",p:1.0},{n:"KRÜ Esports",r:"Americas",p:0.9},{n:"2GAME Esports",r:"Americas",p:0.75},

  {n:"Fnatic",r:"EMEA",p:1.5},{n:"Team Vitality",r:"EMEA",p:1.3},{n:"Team Heretics",r:"EMEA",p:1.25},
  {n:"KOI",r:"EMEA",p:1.2},{n:"Karmine Corp",r:"EMEA",p:1.2},{n:"BBL Esports",r:"EMEA",p:1.15},
  {n:"Team Liquid",r:"EMEA",p:1.05},{n:"Natus Vincere",r:"EMEA",p:1.0},{n:"FUT Esports",r:"EMEA",p:0.9},
  {n:"GIANTX",r:"EMEA",p:0.9},{n:"Gentle Mates",r:"EMEA",p:0.8},{n:"Apeks",r:"EMEA",p:0.75},

  {n:"Paper Rex",r:"Pacific",p:1.5},{n:"T1",r:"Pacific",p:1.4},{n:"DRX",r:"Pacific",p:1.3},
  {n:"ZETA DIVISION",r:"Pacific",p:1.3},{n:"Gen.G",r:"Pacific",p:1.2},{n:"Rex Regum Qeon",r:"Pacific",p:1.15},
  {n:"Nongshim RedForce",r:"Pacific",p:1.05},{n:"TALON",r:"Pacific",p:1.0},{n:"Global Esports",r:"Pacific",p:0.9},
  {n:"Detonation FocusMe",r:"Pacific",p:0.9},{n:"Team Secret",r:"Pacific",p:0.85},{n:"BOOM Esports",r:"Pacific",p:0.8},

  {n:"EDward Gaming",r:"China",p:1.3},{n:"Bilibili Gaming",r:"China",p:1.15},{n:"FunPlus Phoenix",r:"China",p:1.1},
  {n:"JD Gaming",r:"China",p:1.05},{n:"TYLOO",r:"China",p:1.0},{n:"Trace Esports",r:"China",p:0.95},
  {n:"Titan Esports Club",r:"China",p:0.9},{n:"Nova Esports",r:"China",p:0.9},{n:"All Gamers",r:"China",p:0.85},
  {n:"Wolves Esports",r:"China",p:0.8},{n:"Dragon Ranger Gaming",r:"China",p:0.75},{n:"XLG Esports",r:"China",p:0.7}
];

// Event baselines: avg = typical single-match average concurrent viewers,
// peakR = typical peak/average ratio for that event tier, intl = whether
// cross-region matchups get the "international clash" hype bonus.
const events = [
  {name:"VCT Champions — Group Stage", avg:300000, peakR:1.6, intl:true},
  {name:"VCT Champions — Playoffs/Final", avg:600000, peakR:2.1, intl:true},
  {name:"VCT Masters — Group Stage", avg:200000, peakR:1.7, intl:true},
  {name:"VCT Masters — Playoffs/Final", avg:420000, peakR:2.0, intl:true},
  {name:"VCT Kickoff", avg:70000, peakR:1.6, intl:true},
  {name:"Regional League — Americas", avg:90000, peakR:1.6, intl:false},
  {name:"Regional League — Pacific", avg:95000, peakR:1.6, intl:false},
  {name:"Regional League — EMEA", avg:70000, peakR:1.6, intl:false},
  {name:"Regional League — China", avg:15000, peakR:1.7, intl:false},
  {name:"VALORANT Game Changers Championship", avg:15000, peakR:1.8, intl:true}
];
